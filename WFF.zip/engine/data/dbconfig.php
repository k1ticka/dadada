<?PHP

define ("DBHOST", "localhost");

define ("DBNAME", "securitywf");

define ("DBUSER", "root");

define ("DBPASS", "21792399");

define ("PREFIX", "dle");

define ("USERPREFIX", "dle");

define ("COLLATE", "utf8mb4");

define('SECURE_AUTH_KEY', '3Z@9C,Ybn)!|cM/V@65HM``zP;Dr*`o9n9M1NIRZi|~!T<i<6/9p{:GEtN^,oRBB');

$db = new db;

?>